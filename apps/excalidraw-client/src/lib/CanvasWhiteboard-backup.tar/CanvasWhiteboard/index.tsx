import React, {
	useMemo,
	useRef,
	useState,
	forwardRef,
	useLayoutEffect,
	useEffect,
	useCallback,
	useImperativeHandle,
} from "react";
import type {
	Element,
	ElementType,
	Point,
	EraserPoint,
	RemotePointer,
} from "./types";
import { STORAGE_KEY } from "./constants";
import { useLabelEditor } from "./useLabelEditor";
import { useDrawing } from "./useDrawing";
import { useInteractions } from "./useInteractions";
import { useKeyboard } from "./useKeyboard";
import {
	getElementBounds,
	roundElementProperties,
	moveElement,
} from "./element";
import { generateId } from "./id";

import { Toolbar, tools as allToolbarTools } from "./Toolbar/index";
import { Stylebar } from "./Stylebar";
import { useWhiteboard } from "./WhiteboardContext";
// import { WhiteboardContext } from "./WhiteboardContext";

import { WhiteboardUI } from "./WhiteboardUI";
// Defines the virtual canvas dimensions. All element coordinates are relative to this size.
// This allows the canvas to be responsive while maintaining a consistent coordinate system.
const VIRTUAL_WIDTH = 1280;
const VIRTUAL_HEIGHT = 720;

export interface CanvasWhiteboardProps {
	// Component size and styling
	className?: string;

	// State management
	initialElements?: Element[];
	elements?: Element[];
	onElementsChange?: (elements: Element[]) => void;

	// Viewport management
	initialViewTransform?: { scale: number; offsetX: number; offsetY: number };
	viewTransform?: { scale: number; offsetX: number; offsetY: number };
	onViewTransformChange?: (transform: {
		scale: number;
		offsetX: number;
		offsetY: number;
	}) => void;

	// Behavior
	readOnly?: boolean;
	enableLocalStorage?: boolean;
	showToolbar?: boolean;
	enableZoomPan?: boolean;
	enableCursorTracking?: boolean;
	globalKeyboardShortcuts?: boolean;

	// Collaboration props
	remotePointers?: Map<string, RemotePointer>;
	onCursorMove?: (point: Point) => void;
	onStrokeStart?: (element: Element) => void;
	onHighlightStart?: (element: Element) => void;
	onHighlightUpdate?: (strokeId: string, points: Point[]) => void;
	onHighlightEnd?: (strokeId: string) => void;
	onClearHighlights?: () => void;
	inProgressHighlights?: Element[];
	onClear?: () => void;
	inProgressStrokes?: Element[];
	onStrokeEnd?: (strokeId: string, points: Point[]) => void;
	onStrokeUpdate?: (strokeId: string, points: Point[]) => void;
	tools?: ElementType[];
}

export interface CanvasWhiteboardRef {
	clear: () => void;
	getElements: () => Element[];
	setElements: (elements: Element[]) => void;
}

const CanvasWhiteboard = forwardRef<CanvasWhiteboardRef, CanvasWhiteboardProps>(
	(
		{
			className,
			initialElements = [],
			elements: controlledElements,
			onElementsChange,
			initialViewTransform,
			viewTransform: controlledViewTransform,
			onViewTransformChange,
			readOnly = false,
			enableLocalStorage = false,
			showToolbar = true,
			enableZoomPan = true,
			enableCursorTracking = false,
			globalKeyboardShortcuts = true,
			remotePointers,
			onCursorMove,
			onStrokeStart,
			onHighlightStart,
			onHighlightUpdate,
			onHighlightEnd,
			onClearHighlights,
			inProgressHighlights,
			onClear,
			inProgressStrokes,
			onStrokeEnd,
			onStrokeUpdate,
			tools: allowedTools,
		},
		ref
	) => {
		// Refs for DOM elements
		const { selectedElements, setSelectedElements, setSelectedTool } =
			useWhiteboard();
		const containerRef = useRef<HTMLDivElement>(null);
		const toolbarRef = useRef<HTMLDivElement>(null);
		const stylebarRef = useRef<HTMLDivElement>(null);
		const staticCanvasRef = useRef<HTMLCanvasElement>(null); // Bottom canvas for static elements
		const activeCanvasRef = useRef<HTMLCanvasElement>(null); // Top canvas for active/interactive elements

		// State for canvas dimensions and layout
		const [width, setWidth] = useState(0);
		const [height, setHeight] = useState(0);
		const [toolbarHeight, setToolbarHeight] = useState(0);

		// Filter the tools based on the `tools` prop. If not provided, show all.
		const toolbarTools = useMemo(() => {
			if (!allowedTools) {
				return allToolbarTools;
			}

			return allToolbarTools.filter((tool) => allowedTools.includes(tool.name));
		}, [allowedTools]);

		// --- START: State Management ---
		// The component can be "controlled" or "uncontrolled".
		// If the parent passes `elements`, it's controlled. Otherwise, it manages its own state.
		const [internalElements, setInternalElements] = useState<Element[]>(() => {
			if (enableLocalStorage) {
				try {
					const saved = localStorage.getItem(STORAGE_KEY);
					return saved ? JSON.parse(saved) : initialElements;
				} catch (error) {
					console.error("Failed to parse elements from localStorage", error);
					return initialElements;
				}
			}
			return initialElements;
		});
		const elements = controlledElements ?? internalElements;

		const [internalViewTransform, setInternalViewTransform] = useState(
			initialViewTransform || {
				scale: 1, // Zoom level
				offsetX: 0, // Horizontal pan
				offsetY: 0, // Vertical pan
			}
		);
		const viewTransform = controlledViewTransform ?? internalViewTransform;

		// A single callback to handle state updates for both controlled and uncontrolled modes.
		const handleElementsChange = useCallback(
			(newElements: Element[] | ((prevElements: Element[]) => Element[])) => {
				if (onElementsChange) {
					console.log("Calling onElementsChange with", newElements);

					onElementsChange(
						typeof newElements === "function"
							? newElements(elements)
							: newElements
					);
				} else {
					setInternalElements(newElements);
				}
			},
			[elements, onElementsChange]
		);

		const handleViewTransformChange = useCallback(
			(newTransform: { scale: number; offsetX: number; offsetY: number }) => {
				onViewTransformChange
					? onViewTransformChange(newTransform)
					: setInternalViewTransform(newTransform);
			},
			[onViewTransformChange]
		);
		// --- END: State Management ---

		const [drawingAngleInfo, setDrawingAngleInfo] = useState<{
			angle: number;
			x: number;
			y: number;
		} | null>(null);

		const [pointerTrail, setPointerTrail] = useState<EraserPoint[]>([]);

		// State for temporary highlighter scribbles
		const [highlighterScribbles, setHighlighterScribbles] = useState<Element[]>(
			[]
		);

		// State for keyboard modifiers (for panning)
		const [isSpacePressed, setIsSpacePressed] = useState(false);
		const [isCtrlPressed, setIsCtrlPressed] = useState(false);

		// Effect to handle responsive canvas resizing
		useLayoutEffect(() => {
			const container = containerRef.current;
			const toolbar = toolbarRef.current;
			if (!container || !toolbar) return;

			// Use ResizeObserver to efficiently detect size changes of the container and toolbar
			const updateSizes = () => {
				const newToolbarHeight = toolbar.offsetHeight;
				if (newToolbarHeight !== toolbarHeight) {
					setToolbarHeight(0);
				}

				// Calculate canvas size based on container and toolbar height
				const newHeight = container.offsetHeight - newToolbarHeight;
				const newWidth = container.offsetWidth;
				if (newWidth !== width || newHeight !== height) {
					setWidth(newWidth);
					setHeight(newHeight);

					// When size changes, recalculate the view transform to fit the virtual canvas
					// within the new dimensions, centered.
					if (newWidth > 0 && newHeight > 0) {
						const scale = Math.min(
							newWidth / VIRTUAL_WIDTH,
							newHeight / VIRTUAL_HEIGHT
						);
						const offsetX = (newWidth - VIRTUAL_WIDTH * scale) / 2;
						const offsetY = (newHeight - VIRTUAL_HEIGHT * scale) / 2;
						handleViewTransformChange({ scale, offsetX, offsetY });
					}
				}
			};

			const observer = new ResizeObserver(updateSizes);
			observer.observe(container);
			observer.observe(toolbar);

			updateSizes(); // Initial call
			return () => observer.disconnect();
		}, [width, height, toolbarHeight, handleViewTransformChange]); // Dependencies for the effect

		// Effect to save elements to localStorage whenever they change
		useEffect(() => {
			if (!enableLocalStorage) return;
			// Round all numeric properties to 2 decimal places before saving.
			// This keeps the JSON clean and small without sacrificing precision.
			const precision = 2;
			const roundedElements = elements.map((el) =>
				roundElementProperties(el, precision)
			);
			localStorage.setItem(STORAGE_KEY, JSON.stringify(roundedElements));
		}, [elements, enableLocalStorage]);

		// Callback to delete selected elements
		const handleDeleteSelected = useCallback(() => {
			if (selectedElements.length === 0) return;
			const selectedIds = new Set(selectedElements.map((el) => el.id));
			handleElementsChange((prevElements) =>
				prevElements.filter((el) => {
					// Remove the element if it's selected
					if (selectedIds.has(el.id)) {
						return false;
					}
					// Also remove any wires connected to a deleted element
					if (el.type === "wire") {
						return (
							!selectedIds.has(el.startElementId) &&
							!selectedIds.has(el.endElementId)
						);
					}
					return true;
				})
			);
			// setElements((prev) => prev.filter((el) => !selectedIds.has(el.id)));
			setSelectedElements([]);
		}, [selectedElements, handleElementsChange]);

		// Callback to clear highlighter scribbles
		const handleClearScribbles = useCallback(() => {
			if (highlighterScribbles.length > 0) {
				setHighlighterScribbles([]); // Clear local state
			}
			onClearHighlights?.(); // Notify parent to clear for everyone
		}, [highlighterScribbles, onClearHighlights]);

		// Hook to handle keyboard shortcuts (delete, pan keys)
		const { handleKeyDown, handleKeyUp } = useKeyboard({
			onDelete: handleDeleteSelected,
			setIsSpacePressed,
			setIsCtrlPressed,
		});

		// A new callback that encapsulates the logic for selecting a tool.
		// This ensures that clearing highlights happens regardless of how the tool is selected.
		const handleSetSelectedTool = useCallback(
			(tool: ElementType) => {
				// If the user selects the highlighter tool, clear any existing scribbles.
				if (tool === "highlighter") {
					handleClearScribbles();
				}
				setSelectedTool(tool);
				// After selecting a tool, re-focus the canvas for a better user experience.
				const canvas = activeCanvasRef.current;
				if (canvas && document.activeElement !== canvas) {
					canvas.focus();
				}
			},
			[handleClearScribbles, setSelectedTool, activeCanvasRef]
		);

		// Effect to attach keyboard listeners globally if configured.
		// This provides a better "standalone" experience out of the box.
		useEffect(() => {
			if (globalKeyboardShortcuts) {
				// The event handlers from useKeyboard expect React.KeyboardEvent,
				// but window listeners provide KeyboardEvent. We need to cast.
				const onKeyDown = (e: Event) =>
					handleKeyDown(e as unknown as React.KeyboardEvent);
				const onKeyUp = (e: Event) =>
					handleKeyUp(e as unknown as React.KeyboardEvent);

				window.addEventListener("keydown", onKeyDown);
				window.addEventListener("keyup", onKeyUp);
				return () => {
					window.removeEventListener("keydown", onKeyDown);
					window.removeEventListener("keyup", onKeyUp);
				};
			}
		}, [globalKeyboardShortcuts, handleKeyDown, handleKeyUp]);

		// Effect to handle tool selection via keyboard shortcuts (1-9)
		useEffect(() => {
			const handleToolSelection = (e: KeyboardEvent) => {
				// Don't change tools if the user is typing in an input/textarea
				const target = e.target as HTMLElement;
				if (
					target.tagName === "INPUT" ||
					target.tagName === "TEXTAREA" ||
					readOnly
				) {
					return;
				}

				const tool = toolbarTools.find((t) => t.key === e.key);
				if (tool) {
					handleSetSelectedTool(tool.name);
				}
			};

			window.addEventListener("keydown", handleToolSelection);
			return () => {
				window.removeEventListener("keydown", handleToolSelection);
			};
		}, [readOnly, handleSetSelectedTool]);

		// Effect for mouse wheel zoom and pan
		useEffect(() => {
			const canvas = activeCanvasRef.current;
			if (!canvas || !enableZoomPan) return;

			const handleWheel = (event: WheelEvent) => {
				event.preventDefault();
				const { clientX, clientY, deltaX, deltaY, ctrlKey } = event;

				// On most mice, deltaY is for vertical scroll.
				// On trackpads, deltaX/deltaY can be for horizontal/vertical panning.
				// If Ctrl key is pressed, always treat it as zoom.
				if (ctrlKey) {
					// Zooming
					const zoomFactor = 1.1;
					const newScale =
						deltaY < 0
							? viewTransform.scale * zoomFactor
							: viewTransform.scale / zoomFactor;

					const clampedScale = Math.max(0.1, Math.min(newScale, 20));

					const rect = canvas.getBoundingClientRect();
					const mouseX = clientX - rect.left;
					const mouseY = clientY - rect.top;

					// Adjust offset to zoom towards the cursor position
					const newOffsetX =
						mouseX -
						((mouseX - viewTransform.offsetX) * clampedScale) /
							viewTransform.scale;
					const newOffsetY =
						mouseY -
						((mouseY - viewTransform.offsetY) * clampedScale) /
							viewTransform.scale;

					handleViewTransformChange({
						scale: clampedScale,
						offsetX: newOffsetX,
						offsetY: newOffsetY,
					});
				} else {
					// Panning
					handleViewTransformChange({
						...viewTransform,
						offsetX: viewTransform.offsetX - deltaX,
						offsetY: viewTransform.offsetY - deltaY,
					});
				}
			};

			canvas.addEventListener("wheel", handleWheel, { passive: false });
			return () => canvas.removeEventListener("wheel", handleWheel);
		}, [viewTransform, handleViewTransformChange, enableZoomPan]);

		/**
		 * A robust way to update elements in the state.
		 * It handles both creating new elements and updating existing ones.
		 * @param updatedElements An array of elements that have been created or modified.
		 */
		const updateElements = useCallback(
			(updatedElements: Element[]) => {
				console.log("updateElements called with", updatedElements);

				const updatedElementsMap = new Map(
					updatedElements.map((el) => [el.id, el])
				);

				// This handles both updates and creations in a single pass
				handleElementsChange((prevElements) => {
					const newElements = prevElements.map(
						(el) => updatedElementsMap.get(el.id) || el
					);
					const newIds = new Set(newElements.map((el) => el.id));
					// Add any new elements that weren't in the previous state
					updatedElements.forEach((updatedEl) => {
						if (!newIds.has(updatedEl.id)) {
							newElements.push(updatedEl);
						}
					});
					return newElements;
				});
			},
			[handleElementsChange]
		);

		// const { action } = useInteractions({})

		// --- END: Stylebar Logic ---
		// Hook for handling all label/text editing logic
		const {
			editingElement,
			setEditingElement,
			editorPosition,
			labelText,
			textAreaRef,
			handleDoubleClick,
			handleLabelChange,
			handleLabelUpdate,
			handleLabelKeyDown,
		} = useLabelEditor({
			elements,
			updateElements,
			viewTransform,
			activeCanvasRef,
		});

		// Hook for handling all user interactions (drawing, selecting, moving, etc.)
		const {
			selectionRect,
			action,
			wireHoveredElement,
			handlePointerDown,
			handlePointerMove,
			handlePointerUp,
		} = useInteractions({
			activeCanvasRef,
			elements,
			handleElementsChange, // Pass this directly
			updateElements,
			setEditingElement,
			setDrawingAngleInfo,
			viewTransform,
			pointerTrail,
			highlighterScribbles,
			setHighlighterScribbles,
			setPointerTrail,
			setViewTransform: handleViewTransformChange,
			isSpacePressed,
			isCtrlPressed,
			readOnly,
			onCursorMove: enableCursorTracking ? onCursorMove : undefined,
			onStrokeStart,
			onHighlightStart,
			onHighlightUpdate,
			onHighlightEnd,
			onStrokeEnd,
			onStrokeUpdate,
		});
		const [stylebarPosition, setStylebarPosition] = useState<Point | null>(
			null
		);

		const handleStyleChange = useCallback(
			(style: Partial<Element>) => {
				console.log("handleStyleChange called with", style, selectedElements);

				if (selectedElements.length === 0) return;
				const updatedElements = selectedElements.map((el) =>
					Object.assign({}, el, style)
				);
				updateElements(updatedElements);
				setSelectedElements(updatedElements);
			},
			[selectedElements, updateElements, setSelectedElements]
		);

		const handleCopySelected = useCallback(() => {
			if (selectedElements.length === 0) return;

			const newElements = selectedElements.map((element) => {
				const newElement = JSON.parse(JSON.stringify(element));
				newElement.id = generateId();
				// Wires should not be moved on copy, they will reconnect.
				if (newElement.type !== "wire") {
					moveElement(newElement, 15, 15);
				}
				return newElement;
			});

			updateElements(newElements);
			setSelectedElements(newElements);
		}, [selectedElements, updateElements, setSelectedElements]);

		// Hook for handling the rendering of both static and active canvases
		useDrawing({
			staticCanvasRef,
			activeCanvasRef,
			elements,
			action,
			wireHoveredElement,
			editingElement,
			selectionRect,
			drawingAngleInfo,
			pointerTrail,
			remotePointers: enableCursorTracking ? remotePointers : undefined,
			inProgressStrokes,
			inProgressHighlights,
			highlighterScribbles,
			width,
			height,
			virtualWidth: VIRTUAL_WIDTH,
			virtualHeight: VIRTUAL_HEIGHT,
			viewTransform,
		});

		// Handler for the "Clear" button in the toolbar
		const handleClear = () => {
			onClear?.();
			handleElementsChange([]);
			setSelectedElements([]);
		};

		// Expose imperative API to parent components
		useImperativeHandle(ref, () => ({
			clear: handleClear,
			getElements: () => elements,
			setElements: (newElements) => handleElementsChange(newElements),
		}));

		return (
			<WhiteboardUI
				ref={containerRef} // This now works like a regular prop
				className={className}
				globalKeyboardShortcuts={globalKeyboardShortcuts}
				showToolbar={showToolbar}
				toolbarTools={toolbarTools}
				handleSetSelectedTool={handleSetSelectedTool}
				handleDeleteSelected={handleDeleteSelected}
				handleClear={handleClear}
				handleStyleChange={handleStyleChange}
				handleCopySelected={handleCopySelected}
				toolbarHeight={toolbarHeight}
				handleKeyDown={handleKeyDown}
				handleKeyUp={handleKeyUp}
				toolbarRef={toolbarRef}
				stylebarRef={stylebarRef}
				staticCanvasRef={staticCanvasRef}
				activeCanvasRef={activeCanvasRef}
				highlighterScribbles={highlighterScribbles}
				readOnly={readOnly}
				action={action}
				editingElement={editingElement}
				editorPosition={editorPosition}
				labelText={labelText}
				textAreaRef={textAreaRef}
				handleDoubleClick={handleDoubleClick}
				handleLabelChange={handleLabelChange}
				handleLabelUpdate={handleLabelUpdate}
				handleLabelKeyDown={handleLabelKeyDown}
				handlePointerDown={handlePointerDown}
				handlePointerMove={handlePointerMove}
				handlePointerUp={handlePointerUp}
				viewTransform={viewTransform}
				width={width}
				height={height}
			/>
		);
	}
);
CanvasWhiteboard.displayName = "CanvasWhiteboard";

export default CanvasWhiteboard;
