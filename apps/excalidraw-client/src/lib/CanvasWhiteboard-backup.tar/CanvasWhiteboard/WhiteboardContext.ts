import React, { createContext, useContext } from "react";
import type { Element } from "./types";

interface WhiteboardContextType {
	selectedElements: Element[];
	setSelectedElements: React.Dispatch<React.SetStateAction<Element[]>>;
	selectedTool: string;
	setSelectedTool: React.Dispatch<React.SetStateAction<string>>;
}

export const WhiteboardContext = createContext<WhiteboardContextType | null>(
	null
);

/**
 * A custom hook to consume the WhiteboardContext.
 * It ensures that the context is used within a provider.
 */
export const useWhiteboard = (): WhiteboardContextType => {
	const context = useContext(WhiteboardContext);
	if (!context) {
		throw new Error("useWhiteboard must be used within a WhiteboardProvider");
	}
	return context;
};
