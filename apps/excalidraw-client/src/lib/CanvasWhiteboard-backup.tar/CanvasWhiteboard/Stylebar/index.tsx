import React, { useState, useEffect } from "react";
import type { Element } from "../types";
import "./Stylebar.css";
interface StylebarProps {
	selectedElements: Element[];
	onStyleChange: (style: Partial<Element>) => void;
	onDelete: () => void;
	onCopy: () => void;
	toolbarHeight: number;
	ref: React.Ref<HTMLDivElement>;
}

const strokeColors = [
	"#1e1e1e", // Excalidraw black
	"#e03131", // Excalidraw red
	"#2f9e44", // Excalidraw green
	"#1971c2", // Excalidraw blue
	"#f08c00", // Excalidraw orange
];

const fillColors = [
	"transparent",
	"#ffc9c9", // Light red
	"#b2f2bb", // Light green
	"#a5d8ff", // Light blue
	"#ffd8a8", // Light orange
];

const ColorPalette: React.FC<{
	onColorChange: (color: string) => void;
	selectedColor?: string;
	colors: string[];
}> = ({ onColorChange, selectedColor, colors }) => (
	<div className="flex gap-1">
		{colors.map((color) => (
			<button
				key={color}
				title={color}
				className={`color-swatch w-5 h-5 rounded-sm border transition-all duration-100 ${
					selectedColor === color
						? "ring-2 ring-blue-500 ring-offset-1"
						: "border-gray-200 hover:border-gray-400"
				}`}
				style={{ backgroundColor: color }}
				onClick={() => onColorChange(color)}
			/>
		))}
	</div>
);

const StylebarComponent: React.FC<StylebarProps> = ({
	selectedElements,
	onStyleChange,
	onCopy,
	onDelete,
	toolbarHeight,
	ref,
}) => {
	// --- START: Multi-select style aggregation ---
	const getCommonValue = (prop: keyof Element) => {
		const firstValue = (selectedElements[0] as any)[prop];
		if (selectedElements.every((el) => (el as any)[prop] === firstValue)) {
			return firstValue;
		}
		return undefined; // Indicates a "mixed" state
	};

	const commonStroke = getCommonValue("stroke");
	const commonFill = getCommonValue("fill");
	const commonStrokeWidth = getCommonValue("strokeWidth");
	const commonRotation = getCommonValue("rotation");
	const commonOpacity = getCommonValue("opacity");

	// --- START: Local state for deferred updates ---
	const [localRotation, setLocalRotation] = useState(commonRotation || 0);
	const [localStrokeWidth, setLocalStrokeWidth] = useState(
		commonStrokeWidth || 1
	);

	const [localOpacity, setLocalOpacity] = useState(commonOpacity ?? 1);

	useEffect(() => {
		// Reset local state when the selection changes
		setLocalRotation(commonRotation || 0);
		setLocalStrokeWidth(commonStrokeWidth || 1);
		setLocalOpacity(commonOpacity ?? 1);
	}, [commonRotation, commonStrokeWidth, commonOpacity]);
	// --- END: Local state for deferred updates ---

	if (selectedElements.length === 0) {
		// Should not happen with new logic, but good guard
		return null;
	}
	console.log("Stylebar rendering with selectedElements:", selectedElements);

	// Determine which controls to show. Only show if all selected elements have the property.
	const showStroke = selectedElements.every((el) => {
		return "stroke" in el && el["stroke"] !== undefined;
	});
	const showFill = selectedElements.every((el) => {
		return "fill" in el && el["fill"] !== undefined;
	});
	const showStrokeWidth = selectedElements.every((el) => {
		return "strokeWidth" in el && el["strokeWidth"] !== undefined;
	});
	const showRotation = selectedElements.every(
		(el) => "rotation" in el && el["rotation"] !== undefined
	);
	const showOpacity = selectedElements.every(
		(el) => "opacity" in el && el["opacity"] !== undefined
	);
	// --- END: Multi-select style aggregation ---

	const handleStrokeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		console.log("handleStrokeChange called with", e.target.value);

		onStyleChange({ stroke: e.target.value });
	};

	const handleFillChange = (e: React.ChangeEvent<HTMLInputElement>) => {
		onStyleChange({ fill: e.target.value });
	};

	const handleStrokeWidthInput = (e: React.ChangeEvent<HTMLInputElement>) => {
		const newWidth = parseInt(e.target.value, 10) || 1;
		setLocalStrokeWidth(newWidth);
		// Update in real-time
		onStyleChange({ strokeWidth: newWidth });
	};

	const handleRotationInput = (e: React.ChangeEvent<HTMLInputElement>) => {
		// Update local state in real-time while dragging
		setLocalRotation(parseInt(e.target.value, 10));
	};

	const handleRotationChange = () => {
		// Commit the final value to the canvas state on release
		onStyleChange({
			rotation: (localRotation + 360) % 360,
		});
	};

	const handleOpacityInput = (e: React.ChangeEvent<HTMLInputElement>) => {
		const newOpacity = parseFloat(e.target.value);
		setLocalOpacity(newOpacity);
		onStyleChange({
			opacity: newOpacity,
		});
	};

	return (
		<div
			ref={ref}
			className="stylebar"
			style={{
				position: "fixed",
				top: `${toolbarHeight + 124}px`, // Position below the main toolbar
				left: "16px",
				padding: "12px",
				backgroundColor: "white",
				borderRadius: "8px",
				boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
				display: "flex",
				flexDirection: "column", // Stack items vertically
				gap: "16px", // Adjust gap for vertical layout
				alignItems: "stretch",
				zIndex: 100,
			}}
		>
			<div className="flex border border-gray-200 rounded">
				<button
					onClick={onCopy}
					title="Copy selected elements"
					className="p-2 rounded-l hover:bg-gray-100"
				>
					{/* A simple SVG for a copy icon */}
					<svg
						xmlns="http://www.w3.org/2000/svg"
						width="16"
						height="16"
						viewBox="0 0 24 24"
						fill="none"
						stroke="currentColor"
						strokeWidth="2"
						strokeLinecap="round"
						strokeLinejoin="round"
					>
						<rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
						<path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
					</svg>
				</button>
				<button
					onClick={onDelete}
					title="Delete selected elements"
					className="p-2 rounded-r hover:bg-gray-100 border-l border-gray-200"
				>
					{/* A simple SVG for a trash icon */}
					<svg
						xmlns="http://www.w3.org/2000/svg"
						width="16"
						height="16"
						viewBox="0 0 24 24"
						fill="none"
						stroke="currentColor"
						strokeWidth="2"
						strokeLinecap="round"
						strokeLinejoin="round"
					>
						<polyline points="3 6 5 6 21 6"></polyline>
						<path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
					</svg>
				</button>
			</div>
			{showStroke && (
				<div className="flex flex-col items-start gap-2">
					<label className="text-xs font-medium text-gray-500 self-center">
						Stroke
					</label>
					<div className="flex items-center gap-2">
						<ColorPalette
							onColorChange={(color) => onStyleChange({ stroke: color })}
							colors={strokeColors}
							selectedColor={commonStroke}
						/>
						<div className="w-6 h-6 rounded-sm border border-gray-200 overflow-hidden cursor-pointer">
							<input
								type="color"
								id="stroke-color"
								value={commonStroke || "#000000"} // Fallback to black if mixed
								onChange={handleStrokeChange}
								className="w-8 h-8 -m-1 cursor-pointer border-none"
							/>
						</div>
					</div>
				</div>
			)}
			{showFill && (
				<div className="flex flex-col items-start gap-2">
					<label className="text-xs font-medium text-gray-500 self-center">
						Fill
					</label>
					<div className="flex items-center gap-2">
						<ColorPalette
							onColorChange={(color) => onStyleChange({ fill: color })}
							colors={fillColors}
							selectedColor={commonFill}
						/>
						<div className="w-6 h-6 rounded-sm border border-gray-200 overflow-hidden cursor-pointer">
							<input
								type="color"
								id="fill-color"
								value={commonFill || "#000000"} // Fallback to black if mixed
								onChange={handleFillChange}
								className="w-8 h-8 -m-1 cursor-pointer border-none"
							/>
						</div>
					</div>
				</div>
			)}
			{showStrokeWidth && (
				<div className="flex flex-col items-start gap-2">
					<label
						htmlFor="stroke-width"
						className="text-xs font-medium text-gray-500 self-center"
					>
						Width
					</label>
					<input
						type="range"
						id="stroke-width"
						min="1"
						max="50"
						value={localStrokeWidth}
						onInput={handleStrokeWidthInput}
						className="range-slider"
					/>
				</div>
			)}
			{showRotation && (
				<div className="flex flex-col items-start gap-2">
					<label
						htmlFor="rotation"
						className="text-xs font-medium text-gray-500 self-center"
					>
						Rotate
					</label>
					<input
						type="range"
						id="rotation"
						min="0"
						max="360"
						onInput={handleRotationInput}
						value={(localRotation + 360) % 360}
						onMouseUp={handleRotationChange}
						className="range-slider"
					/>
				</div>
			)}
			{showOpacity && (
				<div className="flex flex-col items-start gap-2">
					<label
						htmlFor="opacity"
						className="text-xs font-medium text-gray-500 self-center"
					>
						Opacity
					</label>
					<input
						type="range"
						id="opacity"
						min="0"
						max="1"
						step="0.05"
						value={localOpacity}
						onInput={handleOpacityInput}
						className="range-slider"
					/>
				</div>
			)}
		</div>
	);
};

StylebarComponent.displayName = "Stylebar";

export const Stylebar = React.memo(StylebarComponent);
