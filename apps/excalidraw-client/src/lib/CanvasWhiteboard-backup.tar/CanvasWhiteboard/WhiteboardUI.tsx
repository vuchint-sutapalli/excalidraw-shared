import React from "react";
import type { Element, ElementType, Point } from "./types";
import { Toolbar } from "./Toolbar/index";
import { Stylebar } from "./Stylebar";
import { LabelEditor } from "./LabelEditor";
import { useWhiteboard } from "./WhiteboardContext";

interface WhiteboardUIProps {
	className?: string;
	globalKeyboardShortcuts: boolean;
	showToolbar: boolean;
	toolbarTools: any[];
	handleSetSelectedTool: (tool: ElementType) => void;
	handleDeleteSelected: () => void;
	handleClear: () => void;
	handleStyleChange: (style: Partial<Element>) => void;
	handleCopySelected: () => void;
	toolbarHeight: number;
	handleKeyDown: (e: React.KeyboardEvent) => void;
	handleKeyUp: (e: React.KeyboardEvent) => void;
	toolbarRef: React.RefObject<HTMLDivElement>;
	stylebarRef: React.RefObject<HTMLDivElement>;
	staticCanvasRef: React.RefObject<HTMLCanvasElement>;
	activeCanvasRef: React.RefObject<HTMLCanvasElement>;
	// selectedTool: ElementType;
	highlighterScribbles: Element[];
	readOnly: boolean;
	action: string;
	editingElement: Element | null;
	editorPosition: Point | null;
	labelText: string;
	textAreaRef: React.RefObject<HTMLTextAreaElement>;
	handleDoubleClick: (e: React.MouseEvent<HTMLCanvasElement>) => void;
	handleLabelChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
	handleLabelUpdate: () => void;
	handleLabelKeyDown: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void;
	handlePointerDown: (e: React.PointerEvent<HTMLCanvasElement>) => void;
	handlePointerMove: (e: React.PointerEvent<HTMLCanvasElement>) => void;
	handlePointerUp: (e: React.PointerEvent<HTMLCanvasElement>) => void;
	viewTransform: { scale: number; offsetX: number; offsetY: number };
	width: number;
	height: number;
	ref: React.Ref<HTMLDivElement>;
}

export const WhiteboardUI: React.FC<WhiteboardUIProps> = (props) => {
	const {
		ref,
		className,
		globalKeyboardShortcuts,
		showToolbar,
		toolbarTools,
		handleSetSelectedTool,
		handleDeleteSelected,
		handleClear,
		handleStyleChange,
		handleCopySelected,
		toolbarHeight,
		handleKeyDown,
		handleKeyUp,
		toolbarRef,
		stylebarRef,
		staticCanvasRef,
		activeCanvasRef,
		// selectedTool,
		// selectedElements,
		highlighterScribbles,
		readOnly,
		action,
		editingElement,
		editorPosition,
		labelText,
		textAreaRef,
		handleDoubleClick,
		handleLabelChange,
		handleLabelUpdate,
		handleLabelKeyDown,
		handlePointerDown,
		handlePointerMove,
		handlePointerUp,
		viewTransform,
		width,
		height,
	} = props;

	const { selectedElements, selectedTool } = useWhiteboard();

	return (
		<div
			ref={ref}
			className={`app-container font-virgil relative ${className || ""}`}
			style={{ width: "100%", height: "100%" }}
			tabIndex={globalKeyboardShortcuts ? -1 : 0}
			onKeyDown={globalKeyboardShortcuts ? undefined : handleKeyDown}
			onKeyUp={globalKeyboardShortcuts ? undefined : handleKeyUp}
		>
			{showToolbar && (
				<Toolbar
					activeCanvasRef={activeCanvasRef}
					ref={toolbarRef}
					selectedTool={selectedTool}
					setSelectedTool={handleSetSelectedTool}
					handleDeleteSelected={handleDeleteSelected}
					selectedElements={selectedElements}
					handleClear={handleClear}
					tools={toolbarTools}
					highlighterScribbles={highlighterScribbles}
					readOnly={readOnly}
				/>
			)}

			{selectedElements.length > 0 && action === "none" && (
				<Stylebar
					ref={stylebarRef}
					selectedElements={selectedElements}
					onStyleChange={handleStyleChange}
					onCopy={handleCopySelected}
					onDelete={handleDeleteSelected}
					toolbarHeight={toolbarHeight}
				/>
			)}
			{editingElement && editorPosition && (
				<LabelEditor
					ref={textAreaRef}
					value={labelText}
					onChange={handleLabelChange}
					onBlur={handleLabelUpdate}
					onKeyDown={handleLabelKeyDown}
					style={{
						top:
							editorPosition.y * viewTransform.scale +
							viewTransform.offsetY +
							toolbarHeight,
						left:
							editorPosition.x * viewTransform.scale + viewTransform.offsetX,
					}}
				/>
			)}
			<canvas
				ref={staticCanvasRef}
				width={width}
				height={height}
				style={{
					position: "absolute",
					left: 0,
					top: `${toolbarHeight}px`,
					width: `${width}px`,
					height: `${height}px`,
					border: "1px solid #ccc",
					touchAction: "none",
				}}
			/>
			<canvas
				ref={activeCanvasRef}
				width={width}
				height={height}
				style={{
					position: "absolute",
					left: 0,
					top: `${toolbarHeight}px`,
					width: `${width}px`,
					height: `${height}px`,
					zIndex: 1,
					touchAction: "none",
				}}
				onPointerDown={handlePointerDown}
				onPointerMove={handlePointerMove}
				onPointerUp={handlePointerUp}
				onDoubleClick={handleDoubleClick}
			/>
		</div>
	);
};

WhiteboardUI.displayName = "WhiteboardUI";
