import React, { useLayoutEffect } from "react";

interface LabelEditorProps {
	value: string;
	onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
	onBlur: () => void;
	onKeyDown: (e: React.KeyboardEvent<HTMLTextAreaElement>) => void;
	style: React.CSSProperties;
	// The ref is now a regular prop
	ref: React.Ref<HTMLTextAreaElement>;
}

export const LabelEditor: React.FC<LabelEditorProps> = ({
	value,
	onChange,
	onBlur,
	onKeyDown,
	style,
	ref,
}) => {
	// Auto-resize the textarea based on content
	useLayoutEffect(() => {
		const textarea = (ref as React.RefObject<HTMLTextAreaElement>)?.current;
		if (textarea) {
			// Reset height to shrink if needed
			textarea.style.height = "auto";
			// Set height to scroll height
			textarea.style.height = `${textarea.scrollHeight}px`;
		}
	}, [value, ref]);

	const textareaStyle: React.CSSProperties = {
		position: "absolute",
		...style,
		transform: "translate(-50%, -50%)", // Center the textarea on the element
		zIndex: 10, // Ensure it's on top
		// Subtle styling for an "in-place" feel
		border: "1px dashed #7ab2ff",
		backgroundColor: "rgba(230, 242, 255, 0.8)",
		color: "#1e1e1e",
		padding: "4px",
		borderRadius: "2px",
		resize: "none",
		textAlign: "center",
		minWidth: "40px",
		outline: "none",
		fontFamily: "'vrgil', sans-serif",
		fontSize: "16px",
		overflow: "hidden", // Hide scrollbar
	};

	return (
		<textarea
			ref={ref}
			value={value}
			onChange={onChange}
			onBlur={onBlur}
			onKeyDown={onKeyDown}
			style={textareaStyle}
			rows={1}
		/>
	);
};

LabelEditor.displayName = "LabelEditor";
