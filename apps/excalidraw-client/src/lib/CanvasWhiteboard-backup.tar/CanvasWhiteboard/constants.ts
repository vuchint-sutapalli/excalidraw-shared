export const STORAGE_KEY = "level0_hybrid_whiteboard";
export const HANDLE_SIZE = 15;
export const LINE_HIT_THRESHOLD = 5;

export const HOVER_LENIENCY = 30;

export const MIN_SIZE_THRESHOLD = 10;
// You can switch between 'gradient' and 'segments' to see the difference.
// 'gradient' is more performant and smoother.
// 'segments' is the original implementation that can show "dots" at intersections.
export const TRAIL_RENDERING_STRATEGY: "gradient" | "segments" = "segments";
