import React, { useLayoutEffect, useState } from "react";
import type { Element, ElementType } from "./types";
import { Toolbar } from "./Toolbar/toolbar";
import { Stylebar } from "./Stylebar";
import { LabelEditor } from "./LabelEditor";
import { useLabelEditor } from "./useLabelEditor";
import { useInteractions } from "./useInteractions";
import { useDrawing } from "./useDrawing";
import { useWhiteboard } from "./WhiteboardContext";
import { VIRTUAL_HEIGHT, VIRTUAL_WIDTH } from "./constants";
interface WhiteboardUIProps {
	className?: string;
	globalKeyboardShortcuts: boolean;
	showToolbar: boolean;
	toolbarTools: {
		name: ElementType;
		label: string;
		icon: JSX.Element;
		key?: string;
	}[];
	handleSetSelectedTool: (tool: ElementType) => void;
	handleDeleteSelected: () => void;
	handleClear: () => void;
	handleStyleChange: (style: Partial<Element>) => void;
	handleCopySelected: () => void;
	// toolbarHeight: number;
	handleKeyDown: (e: React.KeyboardEvent) => void;
	handleKeyUp: (e: React.KeyboardEvent) => void;
	toolbarRef: React.RefObject<HTMLDivElement>;
	stylebarRef: React.RefObject<HTMLDivElement>;
	ref: React.Ref<HTMLDivElement>;
	handleViewTransformChange: (transform: {
		scale: number;
		offsetX: number;
		offsetY: number;
	}) => void;
}

export const WhiteboardUI: React.FC<WhiteboardUIProps> = (props) => {
	const {
		ref,
		className,
		globalKeyboardShortcuts,
		showToolbar,
		toolbarTools,
		handleSetSelectedTool,
		handleDeleteSelected,
		handleClear,
		handleStyleChange,
		handleCopySelected,
		// toolbarHeight,
		handleKeyDown,
		handleKeyUp,
		toolbarRef,
		stylebarRef,

		handleViewTransformChange,
	} = props;

	const {
		staticCanvasRef,
		activeCanvasRef,
		highlighterScribbles,
		readOnly,
		action,
		editingElement,
		viewTransform,
		selectedElements,
		selectedTool,
	} = useWhiteboard();
	// State for canvas dimensions and layout
	const [width, setWidth] = useState(0);
	const [height, setHeight] = useState(0);
	const [toolbarHeight, setToolbarHeight] = useState(0);

	const {
		editorPosition,
		labelText,
		textAreaRef,
		handleDoubleClick,
		handleLabelChange,
		handleLabelUpdate,
		handleLabelKeyDown,
	} = useLabelEditor();

	const { handlePointerDown, handlePointerMove, handlePointerUp } =
		useInteractions();

	// Effect to handle responsive canvas resizing
	useLayoutEffect(() => {
		const container = (ref as React.RefObject<HTMLDivElement>)?.current;
		const toolbar = toolbarRef.current;
		if (!container || !toolbar) return;

		const observer = new ResizeObserver(() => {
			const newToolbarHeight = toolbar.offsetHeight;
			setToolbarHeight(newToolbarHeight);
			const newHeight = container.offsetHeight - newToolbarHeight;
			const newWidth = container.offsetWidth;
			setWidth(newWidth);
			setHeight(newHeight);

			// When size changes, recalculate the view transform to fit the virtual canvas
			// within the new dimensions, centered.
			if (newWidth > 0 && newHeight > 0) {
				const scale = Math.min(
					newWidth / VIRTUAL_WIDTH,
					newHeight / VIRTUAL_HEIGHT
				);
				const offsetX = (newWidth - VIRTUAL_WIDTH * scale) / 2;
				const offsetY = (newHeight - VIRTUAL_HEIGHT * scale) / 2;
				handleViewTransformChange({ scale, offsetX, offsetY });
			}
		});
		observer.observe(container);
		observer.observe(toolbar); // Also observe the toolbar for height changes

		return () => {
			observer.disconnect();
		};
	}, [ref, toolbarRef, handleViewTransformChange]);

	useDrawing();

	return (
		<div
			ref={ref}
			className={`app-container ${className || ""}`}
			style={{ width: "100%", height: "100%" }}
			tabIndex={globalKeyboardShortcuts ? -1 : 0}
			onKeyDown={globalKeyboardShortcuts ? undefined : handleKeyDown}
			onKeyUp={globalKeyboardShortcuts ? undefined : handleKeyUp}
		>
			{showToolbar && (
				<Toolbar
					activeCanvasRef={activeCanvasRef}
					ref={toolbarRef}
					selectedTool={selectedTool}
					setSelectedTool={handleSetSelectedTool}
					handleDeleteSelected={handleDeleteSelected}
					selectedElements={selectedElements}
					handleClear={handleClear}
					tools={toolbarTools}
					highlighterScribbles={highlighterScribbles}
					readOnly={readOnly}
				/>
			)}

			{selectedElements.length > 0 && action === "none" && (
				<Stylebar
					ref={stylebarRef}
					selectedElements={selectedElements}
					onStyleChange={handleStyleChange}
					onCopy={handleCopySelected}
					onDelete={handleDeleteSelected}
					toolbarHeight={toolbarHeight}
				/>
			)}
			{editingElement && editorPosition && (
				<LabelEditor
					ref={textAreaRef}
					value={labelText}
					onChange={handleLabelChange}
					onBlur={handleLabelUpdate}
					onKeyDown={handleLabelKeyDown}
					style={{
						top:
							editorPosition.y * viewTransform.scale +
							viewTransform.offsetY +
							toolbarHeight,
						left:
							editorPosition.x * viewTransform.scale + viewTransform.offsetX,
					}}
				/>
			)}
			<canvas
				ref={staticCanvasRef}
				width={width}
				height={height}
				style={{
					position: "absolute",
					left: 0,
					top: `${toolbarHeight}px`,
					width: `${width}px`,
					height: `${height}px`,
					border: "1px solid #ccc",
					touchAction: "none",
				}}
			/>
			<canvas
				ref={activeCanvasRef}
				width={width}
				height={height}
				style={{
					position: "absolute",
					left: 0,
					top: `${toolbarHeight}px`,
					width: `${width}px`,
					height: `${height}px`,
					zIndex: 1,
					touchAction: "none",
				}}
				onPointerDown={handlePointerDown}
				onPointerMove={handlePointerMove}
				onPointerUp={(e) => handlePointerUp(e)}
				onDoubleClick={handleDoubleClick}
			/>
		</div>
	);
};

WhiteboardUI.displayName = "WhiteboardUI";
